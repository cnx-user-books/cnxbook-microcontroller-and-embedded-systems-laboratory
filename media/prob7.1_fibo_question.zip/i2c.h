/*******************************************************************************
  
  header file for i2c and prob7.1 (fibonacci optimization)
  
*******************************************************************************/

#define __7SEG_A  0x01
#define __7SEG_B  0x02
#define __7SEG_C  0x04
#define __7SEG_D  0x08
#define __7SEG_E  0x10
#define __7SEG_F  0x20
#define __7SEG_G  0x40
#define __7SEG_DP 0x80

#define __7SEG_0  ~(__7SEG_A | __7SEG_B | __7SEG_C | __7SEG_D | __7SEG_E | __7SEG_F)
#define __7SEG_1  ~(__7SEG_B | __7SEG_C)
#define __7SEG_2  ~(__7SEG_A | __7SEG_B | __7SEG_G | __7SEG_E | __7SEG_D)
#define __7SEG_3  ~(__7SEG_A | __7SEG_B | __7SEG_G | __7SEG_C | __7SEG_D)
#define __7SEG_4  ~(__7SEG_F | __7SEG_G | __7SEG_B | __7SEG_C)
#define __7SEG_5  ~(__7SEG_A | __7SEG_F | __7SEG_G | __7SEG_C | __7SEG_D)
#define __7SEG_6  ~(__7SEG_A | __7SEG_F | __7SEG_G | __7SEG_C | __7SEG_D  | __7SEG_E)
#define __7SEG_7  ~(__7SEG_F | __7SEG_A | __7SEG_B | __7SEG_C)
#define __7SEG_8  ~(__7SEG_A | __7SEG_B | __7SEG_C | __7SEG_D | __7SEG_E | __7SEG_F | __7SEG_G)
#define __7SEG_9  ~(__7SEG_A | __7SEG_B | __7SEG_C | __7SEG_D | __7SEG_F | __7SEG_G)
#define __7SEG_a  ~(__7SEG_A | __7SEG_B | __7SEG_C | __7SEG_E | __7SEG_F | __7SEG_G)
#define __7SEG_b  ~(__7SEG_C | __7SEG_D | __7SEG_E | __7SEG_F | __7SEG_G)
#define __7SEG_c  ~(__7SEG_A | __7SEG_D | __7SEG_E | __7SEG_F)
#define __7SEG_d  ~(__7SEG_B | __7SEG_C | __7SEG_D | __7SEG_E | __7SEG_G)
#define __7SEG_e  ~(__7SEG_A | __7SEG_D | __7SEG_E | __7SEG_F | __7SEG_G)
#define __7SEG_f  ~(__7SEG_A | __7SEG_E | __7SEG_F | __7SEG_G)

static int segments[] =
{
  __7SEG_0, __7SEG_1, __7SEG_2, __7SEG_3, __7SEG_4, __7SEG_5, __7SEG_6, __7SEG_7,
  __7SEG_8, __7SEG_9, __7SEG_a, __7SEG_b, __7SEG_c, __7SEG_d, __7SEG_e, __7SEG_f
};


#define SLAVE1 0x3e
#define SLAVE2 0x3f
#define SLAVE3 0x3d

void initialize_i2c(void);
void set_pcf(char byte, int slave);
int transmit_byte(int slave, char byte);
long fibo(int n);

