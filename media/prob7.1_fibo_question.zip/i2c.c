/****************************************************************
  
    i2c initialization
  
****************************************************************/

#include  <msp430x16x.h>
#include "i2c.h"

void initialize_i2c(void)
{
  unsigned int foo;

  P3SEL |= 0x0A;
  U0CTL |= I2C+SYNC+MST;
  U0CTL &= ~I2CEN;
  // config module
  I2CTCTL |=  I2CSSEL0+I2CSSEL1;
  I2CNDAT = 1; // we are only writing 1 byte of data
  I2CPSC = 4; // 7.8MHz/4+1 = 1.56MHz
  I2CSCLH = 8;
  I2CSCLL = 8; //8+8 = 16 1.56MHz/16 = 10kHz
  I2COA = 0x47;
  // turn on i2c
  U0CTL |= I2CEN;
}


int transmit_byte(int slave, char byte)
{
  unsigned int foo;
 // U0CTL &= ~I2CEN;
  I2CDRB = byte;
  I2CSA = slave;
  U0CTL |= MST;
  I2CTCTL |= I2CTRX+I2CSTT+I2CSTP;
  // U0CTL |= I2CEN;

  // allows time for 7 segment to update
  for (foo=0;foo<1000;foo++){
    _NOP();
  }

  return 1;
}

void set_pcf(char byte, int slave){
  transmit_byte(slave, byte);
  return;
}


