/*******************************************************************************
  
  Problem 7.1 (fibonacci optimization) question code

  This computes the fibonacci sequence of length 50.  Green LED is on while it 
  is computing, red otherwise.

  Optimize this code so that it isn't so slow.   Try to use malloc() and free() 
  whenever possible.  Use a pointer to the array of numbers.
  
  The 7-Segment displays the index of the current number being computed in
  hexidecimal notation. That code may also be optimized.

*******************************************************************************/

#include <__cross_studio_io.h>
#include  <msp430x16x.h> 
#include "i2c.h"


long fib_seq[50]={0};
int index;
int n,j;

void main(void)
{
  int k;
  LPM1;
  initialize_i2c();
  set_pcf(segments[0],SLAVE1);
  set_pcf(segments[0],SLAVE2);
  WDTCTL = WDTPW + WDTHOLD; 
  P2DIR |= 0xe0;  
  P2OUT |= 0xe0;  

  for (n=0; n < 50; n=n+1) 
  {
    j=n-1;
    k=0;
    if (j<16){
      set_pcf(segments[j],SLAVE2);
      set_pcf(segments[0],SLAVE1);
    }
    else{
      while (j>15){
        j=j-16;
        k++;
      }
      set_pcf(segments[j],SLAVE2);
      set_pcf(segments[k],SLAVE1);
    }
    
    index = n;
    P2OUT &= ~0x40;
    P2OUT |= 0x20;
    fib_seq[index] = fibo(index);
    P2OUT &= ~0x20;
    P2OUT |= 0x40;
    debug_printf("index = %d fib_num = %d\n", index, fibo(index));
  }
  
  P2OUT |= 0x40;  
  P2OUT &= ~0x20; 
  while (1);  
}

long fibo(int n) 
{
  P2OUT &= ~0x40;
  P2OUT |= 0x20;
  if (n < 2)
    return n;
  else 
    return fibo(n-1) + fibo(n-2);
  P2OUT &= ~0x20;
  P2OUT |= 0x40;
}

