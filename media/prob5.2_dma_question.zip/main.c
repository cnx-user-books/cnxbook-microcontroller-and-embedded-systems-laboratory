/******************************************************************
 problem 7.2 dma question

 DMA is set to transfer a hard coded sine wave to DAC0. 

 Modify the project to samples ADC channels 2 and 3 simultaniously.  Transfer 
 the data to DAC0 and DAC1, respectivly, using the DMA.  Pushing pushbutton 2 
 should toggles the analog filter cutoffs between 14.75 kHz and 6.7 kHz.
 
******************************************************************/
#include  <msp430x16x.h>
#include "i2c.h"

static int Sin_tab[32] = {
      2048,2247,2439,2616,2771,2898,2993,3051,3071,3051,2993,2898,2771,2616,
      2439,2247,2048,1847,1655,1478,1323,1196,1101,1043,1023,1043,1101,1196,
      1323,1478,1655,1847
};

void main(void)
{

  WDTCTL = WDTPW+WDTHOLD;               // Disable watchdog timer
  //initialize_master_clock();
  initialize_i2c();
  enable_LED;
  set_led(red+green+yellow,0);
  set_pcf(segments[0],SLAVE1);
  set_pcf(segments[0],SLAVE2);
  
  /* IO */
  P2DIR |= 0x04;                        // FILTER_CLK_SWITCH output
  P2OUT &= ~0x04;                       // FILTER_CLK_SWITCH output
  P4DIR |= 0x30;                        // P4.4, P4.5 output
  P4SEL |= 0x30;                        // Select alt function for P4.4
  set_pcf(0x7F,SLAVE3);                 // Enables Filters

  /* TIMER B */
  TBCCR0 = 2;                          // PWM Period ~1.475MHz
  TBCCR2 = TBCCR0/2;                    // CCR1 PWM Duty Cycle   (triggers dac)
  TBCCR4 = TBCCR0/2;                    // 50% duty cycle        (adc filter clk)
  TBCCR5 = TBCCR0/2;                    // 50% duty cycle        (dac filter clk)
  TBCCTL1 = OUTMOD_4;                   // Toggle mode           (triggers adc)
  TBCCTL2 = OUTMOD_3;                   // CCR1 set/reset        (triggers dac)
  TBCCTL4 = OUTMOD_7;                   // Reset/Set output mode (adc filter clk)
  TBCCTL5 = OUTMOD_7;                   // Reset/Set output mode (dac filter clk)
  TBCTL = TBSSEL1 + TBCLR + TBIE;       // SMCLK + Timer_B clear
  TBCTL |= MC0;                         // Start Timer_B in up mode

  /* ADC */
  ADC12CTL0 =  REFON;        		// Internal 1.5V ref

  /* DMA */
  DMA0SA = (int) Sin_tab;               // Source block address
  DMA0DA = DAC12_0DAT_;                 // Destination single address
  DMA0SZ = 0x20;                        // Block size
  DMACTL0 = DMA0TSEL_0;                 // trigger on DMAREQ (software trigger)
  DMA0CTL = DMADT_4 + DMASRCINCR_3;     // Repeat, inc src, word-word
  DMA0CTL |= DMAEN;

  /* DAC */
  DAC12_0CTL = DAC12LSEL_0 + DAC12AMP_5;// Direct load, DAC12 amp:medium/medium (ignores P6)
  DAC12_0CTL |= DAC12IR;                // 1x ref votage
  DAC12_0CTL |=  DAC12IFG + DAC12ENC;   // Start DAC

  while (1)
  { 
    DMA0CTL|=DMAREQ;                    // triggers DMA chan. 0
  }   
}

void initialize_master_clock(void)
{
  unsigned int i; 
  BCSCTL1 &= ~XT2OFF;                   // XT2 = HF XTAL
  do {
    IFG1 &= ~OFIFG;                     // Clear OSCFault flag
    for (i = 0xFF; i > 0; i--);         // Time for flag to set
    }
  while ((IFG1 & OFIFG) == OFIFG);      // OSCFault flag still set?
  BCSCTL2 |= SELS+SELM1;//+DIVS_3;
  P5DIR |= 0x20;                        // P5.5 output direction
  P5SEL |= 0x20;                        // P5.5 = SMCLK option select

  return;
}
